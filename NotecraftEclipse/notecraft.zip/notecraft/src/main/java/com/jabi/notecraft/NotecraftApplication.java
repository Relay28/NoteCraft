package com.jabi.notecraft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotecraftApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotecraftApplication.class, args);
	}

}
